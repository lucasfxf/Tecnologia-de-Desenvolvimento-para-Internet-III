
package br.edu.ifsuldeminas.fundamentoshttp;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/status")
public class StatusServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String code = request.getParameter("code");
        int status = 200;

        try {
            if (code != null) {
                status = Integer.parseInt(code);
            }
        } catch (NumberFormatException e) {
            status = 400;
        }

        response.setStatus(status);
        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<html><head><meta charset='UTF-8'></head><body>");
        out.println("<h1>Teste de Status HTTP</h1>");
        out.println("<h2>Código enviado: " + status + "</h2>");

        if (status == 200) {
            out.println("<p>200 OK - Resposta normal.</p>");
        } else if (status == 404) {
            out.println("<p>404 Not Found - Página não encontrada.</p>");
        } else if (status == 500) {
            out.println("<p>500 Internal Server Error - Erro interno.</p>");
        } else {
            out.println("<p>Código HTTP: " + status + "</p>");
        }

        out.println("</body></html>");
    }
}
