	
	package br.edu.ifsuldeminas.fundamentoshttp;
	
	import java.io.IOException;
	import java.io.PrintWriter;
	import jakarta.servlet.ServletException;
	import jakarta.servlet.annotation.WebServlet;
	import jakarta.servlet.http.HttpServlet;
	import jakarta.servlet.http.HttpServletRequest;
	import jakarta.servlet.http.HttpServletResponse;
	
	@WebServlet("/request-body")
	public class RequestBodyServlet extends HttpServlet {
	
	    @Override
	    protected void doPost(HttpServletRequest request,
	                          HttpServletResponse response)
	            throws ServletException, IOException {
	
	        request.setCharacterEncoding("UTF-8");
	        response.setContentType("text/html;charset=UTF-8");
	
	        String nome = request.getParameter("nome");
	        String email = request.getParameter("email");
	        String mensagem = request.getParameter("mensagem");
	
	        PrintWriter out = response.getWriter();
	
	        out.println("<html><head><meta charset='UTF-8'>");
	        out.println("<title>Corpo da Requisição</title></head><body>");
	        out.println("<h1>Dados recebidos via POST</h1>");
	        out.println("<p><b>Nome:</b> " + nome + "</p>");
	        out.println("<p><b>Email:</b> " + email + "</p>");
	        out.println("<p><b>Mensagem:</b> " + mensagem + "</p>");
	        out.println("</body></html>");
	    }
	}
