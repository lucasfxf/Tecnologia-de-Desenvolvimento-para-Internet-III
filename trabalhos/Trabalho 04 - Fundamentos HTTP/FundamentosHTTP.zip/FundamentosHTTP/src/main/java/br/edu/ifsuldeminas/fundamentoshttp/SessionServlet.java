
package br.edu.ifsuldeminas.fundamentoshttp;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/session")
public class SessionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        Cookie[] cookies = request.getCookies();
        boolean encontrou = false;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("usuario")) {
                    encontrou = true;
                    break;
                }
            }
        }

        if (!encontrou) {
            Cookie cookie = new Cookie("usuario", "X");
            cookie.setMaxAge(60 * 60 * 24);
            cookie.setPath("/");
            response.addCookie(cookie);
        }

        PrintWriter out = response.getWriter();

        out.println("<html><head><meta charset='UTF-8'></head><body>");
        out.println("<h1>Controle de Sessão e Cookies</h1>");
        out.println("<h2>Bem-vindo de volta, usuário 'X'!</h2>");
        out.println("</body></html>");
    }
}
