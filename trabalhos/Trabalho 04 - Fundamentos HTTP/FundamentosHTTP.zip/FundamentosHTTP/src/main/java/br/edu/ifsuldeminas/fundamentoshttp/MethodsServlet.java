
package br.edu.ifsuldeminas.fundamentoshttp;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/methods")
public class MethodsServlet extends HttpServlet {

    @Override
    protected void doOptions(HttpServletRequest request,
                             HttpServletResponse response)
            throws ServletException, IOException {

        response.setHeader("Allow", "GET, POST, PUT, DELETE, OPTIONS, HEAD");

        response.setContentType("text/plain;charset=UTF-8");
        response.getWriter().println(
            "Métodos HTTP suportados pelo servidor:");
        response.getWriter().println(
            "GET, POST, PUT, DELETE, OPTIONS e HEAD");
    }
}
