
package br.edu.ifsuldeminas.fundamentoshttp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/headers")
public class HeadersServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='pt-br'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<title>Análise de Cabeçalhos HTTP</title>");
        out.println("</head>");
        out.println("<body>");

        out.println("<h1>Análise de Cabeçalhos HTTP</h1>");

        out.println("<h2>Informações da requisição</h2>");
        out.println("<p><strong>Endereço IP:</strong> "
                + request.getRemoteAddr() + "</p>");

        out.println("<p><strong>Versão HTTP:</strong> "
                + request.getProtocol() + "</p>");

        out.println("<h2>Cabeçalhos recebidos</h2>");
        out.println("<table border='1' cellpadding='8'>");
        out.println("<tr><th>Cabeçalho</th><th>Valor</th></tr>");

        Enumeration<String> headers = request.getHeaderNames();

        while (headers.hasMoreElements()) {
            String name = headers.nextElement();
            String value = request.getHeader(name);

            out.println("<tr><td>" + name + "</td><td>"
                    + value + "</td></tr>");
        }

        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
    }
}
